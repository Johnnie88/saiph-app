<?php
/**
 * Custom: Company Access Denied Contact Details
 *
 * This template can be overridden by copying it to yourtheme/wp-job-manager-companies/access-denied-contact-details.php.
 *
 * @see         https://wpjobmanager.com/document/template-overrides/
 * @package     Cariera
 * @category    Template
 * @since       1.5.5
 * @version     1.5.5
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**  You can add a message here if you want, for when contact details are not visible */
